<?php

$host = "sql208.infinityfree.com";
$user = "if0_42388767";
$password = "Mudassar1963";
$database = "if0_42388767_forces_academy_db";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

?>